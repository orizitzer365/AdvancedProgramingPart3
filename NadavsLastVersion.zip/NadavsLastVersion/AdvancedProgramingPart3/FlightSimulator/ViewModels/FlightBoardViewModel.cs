﻿using FlightSimulator.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlightSimulator.Model;
using System.Windows.Input;
using System.Windows;
using FlightSimulator.Views;
using System.ComponentModel;

namespace FlightSimulator.ViewModels
{
    public class FlightBoardViewModel : BaseNotify
    {
        private IServerModel sm;
        public FlightBoardViewModel()
        {
            sm = ServerModel.Instance;
            sm.PropertyChanged += new PropertyChangedEventHandler((object sender, PropertyChangedEventArgs e)=>this.NotifyPropertyChanged(e.PropertyName));
        }

        public double Lon
        {
            get
            {
                return sm.Lon;
            }
        }

        public double Lat
        {
            get
            {
                return sm.Lat;
            }
        }

        private ICommand _settingsCommand;
        public ICommand SettingsCommand
        {
            get
            {
                return _settingsCommand ?? (_settingsCommand =
                new CommandHandler(() => OpenSettings()));
            }
        }

        public void OpenSettings()
        {
            Window sett = new SettingsWindow();
            sett.Show();
        }


        private ICommand _connectCommand;
        public ICommand ConnectCommand
        {
            get
            {
                return _connectCommand ?? (_connectCommand =
                new CommandHandler(() => ConnectServers()));
            }
        }

        private void ConnectServers()
        {
            sm.Connect();
        }

        private ICommand _disconnectCommand;
        public ICommand DisconnectCommand
        {
            get
            {
                return _disconnectCommand ?? (_disconnectCommand =
                new CommandHandler(() => DisconnectServers()));
            }
        }

        private void DisconnectServers()
        {
            sm.Disconnect();
        }
    }
}
