﻿using FlightSimulator.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulator.Model
{
    interface IServerModel : INotifyPropertyChanged
    {
        void Connect();
        void Disconnect();
        void Send(String value);
        double Lat
        {
            get;
        }
        double Lon
        {
            get;
        }
        bool IsSending
        {
            get;
        }
    }
}
