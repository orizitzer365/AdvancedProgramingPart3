﻿using FlightSimulator.Model.Interface;
using FlightSimulator.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FlightSimulator.Model
{
    class ServerModel : BaseNotify , IServerModel
    {

        ISettingsModel asm;
        double lat, lon;
        volatile bool stop , isSending;
        TcpListener listener;
        TcpClient infoClient;
        TcpClient commandClient;
        BinaryReader infoReader;
        BinaryWriter commandWriter;
        volatile Queue<String> toSend;
        String buffer;


        #region Singleton
        private static ServerModel m_Instance = null;
        public static ServerModel Instance
        {
            get
            {
                if (m_Instance == null)
                {
                    m_Instance = new ServerModel();
                }
                return m_Instance;
            }
        }

        private ServerModel()
        {
            asm = ApplicationSettingsModel.Instance;
            lat = 0;
            lon = 0;
            stop = true;
            isSending = false;
            toSend = new Queue<string>();
            buffer = "";
        }
        #endregion

        public double Lat
        {
            get
            {
                return lat;
            }
        }

        public double Lon
        {
            get
            {
                return lon;
            }
        }

        public bool IsSending
        {
            get
            {
                return isSending;
            }
        }

        public void Connect()
        {
            stop = false;
            #region InfoServer
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse(asm.FlightServerIP),asm.FlightInfoPort);
            listener = new TcpListener(ep);
            listener.Start();
            infoClient = listener.AcceptTcpClient();
            listener.Stop();
            using (NetworkStream stream = infoClient.GetStream()) using (infoReader = new BinaryReader(stream)) {
                new Task(() =>
                {
                    while (!stop)
                    {
                        buffer += infoReader.ReadString();
                        String[] substrings = buffer.Split('\n');
                        buffer = substrings[substrings.Length - 1];
                        for(int i = 0; i < substrings.Length - 1; ++i)
                        {
                            String[] things = substrings[i].Split(',');
                            lon = double.Parse(things[0]);
                            lat = double.Parse(things[1]);
                            NotifyPropertyChanged("Lon");
                            NotifyPropertyChanged("Lat");
                        }
                    }
                }).Start();
            }
            #endregion

            #region CommandClient
            IPEndPoint ep2 = new IPEndPoint(IPAddress.Parse(asm.FlightServerIP), asm.FlightCommandPort);
            commandClient = new TcpClient();
            commandClient.Connect(ep2);
            using (NetworkStream stream = commandClient.GetStream()) using (commandWriter = new BinaryWriter(stream)) { }
            new Task(() =>
            {
                while (!stop)
                {
                    if (toSend.Count > 0)
                    {
                        if (!isSending)
                        {
                            isSending = true;
                            NotifyPropertyChanged("IsSending");
                        }
                        commandWriter.Write(toSend.Dequeue());
                        commandWriter.Flush();
                    }
                    else if (isSending)
                    {
                        isSending = false;
                        NotifyPropertyChanged("IsSending");
                    }
                    Thread.Sleep(100);
                }
            }).Start();
            #endregion

            
        }

        public void Disconnect()
        {
            stop = true;
            commandClient.Close();
            infoClient.Close();
        }

        public void Send(String value)
        {
            toSend.Enqueue(value);
        }

    }
}
